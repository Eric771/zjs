# AlphatTJ
Bot AlphatTJ@9.9.9 (Pakai Token Chrome Via QR Login)
------
-

NEW
------
- `Mute`
- `Unmute`
- `Add Staff`
- `Delete Staff`

Cara Install Bot AlphatTJ Di Termux :
------
- `pkg install nodejs -y`
- `pkg install git -y`
- `git clone https://github.com/Nadyatjia/AlphatTJ`
- `pkg install nano`
- `cd AlphatTJ`
- `npm install`
- `npm start`

Cara Install Bot AlphatTJ Di C9:
------
- =================  [PROSES UPDATE]  =================
- ==============================================

- `sudo apt-get update`
-`sudo apt-get install build-essential checkinstall libssl-dev`
- `curl -o- https://raw.githubusercontent.com/creationix/nvm/v0.32.1/install.sh | bash`
- `nvm install v8.9.1`
- `nvm use v8.9.1`
- `nvm ls`
- `nvm alias default node`
- =================  [PROSES INSTALL]  =================
- ==============================================
- `sudo apt-get install nodejs`
- `git clone https://github.com/Nadyatjia/AlphaTJ`
- `ls`
- `cd AlphatTJ`
- `npm i`
- `npm i -g npm [apabila ada update]`
- `npm start`

Cara Menjalankan Bot Kembali :
------
- `cd AlphatTJ`
- `npm start`

Credit By@ Nadya Sutjiadi.
------
- `Follow My Instagram : nadya.tjia`
- `Add My ID LINE : nad_nad. (pake titik)`

Thx To :
------
- `Alfatdirk`




